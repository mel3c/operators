## operator-sdk alpha olm

Manage the Operator Lifecycle Manager installation in your cluster

### Synopsis

Manage the Operator Lifecycle Manager installation in your cluster

### Options

```
  -h, --help   help for olm
```

### SEE ALSO

* [operator-sdk alpha](operator-sdk_alpha.md)	 - Run an alpha subcommand
* [operator-sdk alpha olm install](operator-sdk_alpha_olm_install.md)	 - Install Operator Lifecycle Manager in your cluster
* [operator-sdk alpha olm status](operator-sdk_alpha_olm_status.md)	 - Get the status of the Operator Lifecycle Manager installation in your cluster
* [operator-sdk alpha olm uninstall](operator-sdk_alpha_olm_uninstall.md)	 - Uninstall Operator Lifecycle Manager from your cluster

