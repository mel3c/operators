## operator-sdk up

Launches the operator

### Synopsis

The up command has subcommands that can launch the operator in various ways.


### Options

```
  -h, --help   help for up
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease
* [operator-sdk up local](operator-sdk_up_local.md)	 - Launches the operator locally

