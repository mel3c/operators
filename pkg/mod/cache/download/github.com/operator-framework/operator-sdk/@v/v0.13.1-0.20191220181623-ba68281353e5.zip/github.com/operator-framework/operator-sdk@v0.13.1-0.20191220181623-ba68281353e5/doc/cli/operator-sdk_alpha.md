## operator-sdk alpha

Run an alpha subcommand

### Synopsis

Run an alpha subcommand

### Options

```
  -h, --help   help for alpha
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease
* [operator-sdk alpha olm](operator-sdk_alpha_olm.md)	 - Manage the Operator Lifecycle Manager installation in your cluster

