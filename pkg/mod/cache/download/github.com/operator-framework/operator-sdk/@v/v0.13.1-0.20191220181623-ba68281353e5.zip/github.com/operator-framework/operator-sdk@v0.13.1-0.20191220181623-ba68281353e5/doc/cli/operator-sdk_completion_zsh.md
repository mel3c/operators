## operator-sdk completion zsh

Generate zsh completions

### Synopsis

Generate zsh completions

```
operator-sdk completion zsh [flags]
```

### Options

```
  -h, --help   help for zsh
```

### SEE ALSO

* [operator-sdk completion](operator-sdk_completion.md)	 - Generators for shell completions

